﻿var TranslType = "text";
var TS;
var revDir=false; 
var blogPos = "top";
var loadLoginFrame=false;
var tmpDirCode = "";var tmpPos = "";
var topPopup=false;
var curVMode = "vert";
var getFullWRef=false;
var fullWordInfo=0;
var trUID = "";
var savedUID = "";
var uTrType = "";
var visLink = false;
var saveTranslation=false;
var visVLink = false;
var visATWin=false;
var countListTemplCol = 8;
var trDirCode = "";
var wasErr = false; 
var tmpID = "";
var sKbd="ru";
var Show_vkb = false;
var templList =new Array();

function getCookie(name) {
	var cookie = " " + document.cookie;
	var search = " " + name + "=";
	var setStr = null;
	var offset = 0;
	var end = 0;
	if (cookie.length > 0) {
		offset = cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = cookie.indexOf(";", offset)
			if (end == -1) {
				end = cookie.length;
			}
			setStr = unescape(cookie.substring(offset, end));
		}
	}
	return(setStr);
}

function setCookie (name, value, expires, path, domain, secure) {
var today = new Date();
today.setTime( today.getTime() );

if ( expires )
{
expires = expires * 1000 * 60 * 60 * 24;
}
var expires_date = new Date( today.getTime() + (expires) );

      document.cookie = name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires_date.toGMTString() : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}

//var vMode = "auto";
var vMode = (getCookie('vMode'))?getCookie('vMode'):'vert'; 



function rtrim(s){return s.replace(/\s+$/,'')}

