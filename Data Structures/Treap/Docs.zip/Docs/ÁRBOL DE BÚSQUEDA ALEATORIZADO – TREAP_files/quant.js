
<html>
<head>
<title>ACCESO DENEGADO</title>
</head>

<body>


<p align="center">
	<font size="6" face="verdana, arial, helvetica">
	<img border="0" src="/stop.gif" align="middle" width="87" height="88">
	</font>
</p>
<p align="center">
	<b><font size="4" face="verdana, arial,helvetica">
	ACCESO DENEGADO!
	</font></b>
</p>
<p align="center">
	<font size="2" face="verdana, arial, helvetica">
	El acceso al sitio:
	<br>
	<b>
		<font color="#FF0000">
		<a href="http://edge.quantserve.com/quant.js">http://edge.quantserve.com/quant.js</a>
		</font>
	</b>
	</font>
</p>
<p align="center">
	<font size="2" face="verdana, arial, helvetica">
	fue denegado por la siguiente razón:
	<br>
	<b>
	<font color="#FF0000">
	Sitio no permitido : Banned Sites (ads)
	</font>
	</b>
	</font>
</p>
<p align="center">
	<font size="2" face="verdana, arial, helvetica">
	UD. esta viendo este error porque el sitio accedido<br>
	contiene materiales que se consideran inapropiados.
	</font>
</p>
<p align="center">
	<font size="2" face="verdana, arial, helvetica">
	Si Ud. considera que este sitio debe estar permitido, por favor, reportelo a continuación:
	</font>
</p>
<P align="center">
<font size="3" face=verdana, arial, helvetica">
Solo debe llenar este formulario si ud. considera que el contenido del sitio es apropiado.
</FONT>
</P>


<FORM ACTION="/cgi-bin/info.pl" METHOD="POST">
<INPUT type="hidden" name="DENIEDURL" value="http://edge.quantserve.com/quant.js">
<INPUT type="hidden" name="REASON" value="Sitio no permitido: quantserve.com">
<INPUT type="hidden" name="POSTBACK" value=1>
<INPUT type="hidden" name="USER" value=jrarias>
<INPUT type="hidden" name="IP" value=10.58.21.23>


<div align="center">
<center>
<table border="0" width="437">
<tr>
<td width="429">
<table border="0" width="431">
<center>
<tr>
<td valign="top" width="89">
<font face="verdana, arial,helvetica" size="2">Usuario:</font></td>
</center>
<td width="328">
<p align="right"><font face="verdana, arial, helvetica" size="2">
jrarias</font></td>
</tr>
<center>
<tr>
<td valign="top" width="89"><font face="verdana, arial,
helvetica" size="2">Aclaración:</font></td>
</center>
<td width="328">
<p align="right"><font face="verdana, arial, helvetica" size="2">
<textarea rows="4" name="ERROR" cols="40"></textarea></font></td>
</tr>
</table>
<center>
</center></td>
</tr>
</table>
</div>
  <p align="center">
  <font face="verdana, arial, helvetica">
  <input type="submit" value="Enviar" name="B1">&nbsp;
  <input type="reset" value="Limpiar" name="B2"></font></p>
</form>
<p align="center">
	<i>
	<font face="verdana, arial,helvetica" size="1">
	
	<a href="http://stelematicos.uci.cu">Servicios Telemáticos</a>
	UCI
	</font>
	</i>
</p>

</body>

</html>


